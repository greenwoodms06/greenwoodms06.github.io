# Soul System measurement program — results bundle

The locked-prediction paper trail behind the blogs and papers, reader-sized.
Project identities from the base-rate mining are anonymized (PLANT-BOP /
GAME-A / RESEARCH-N); everything else is verbatim.

## What's here

- `study/` — the measurement writeups (`00`–`08`), the results tables, the
  calibration-gradient figure, and the v1-evaluation study log (the lab
  notebook for the ~390-session probe battery at Haiku 4.5 / Sonnet 4.6 /
  Opus 4.8).
- `experiments/` — for every experiment: the **PREDICTION** file (locked
  before any arm ran), the **RESULT** file (scored against artifacts), and
  the program **VERDICT**. Misses are reported with the same prominence as
  hits. The base-rate mining reports (one per real project, anonymized) are
  included in full.

## What's NOT here

The arm repositories — the actual code each condition produced (~100+ MB).
They live in the public `soul-benchmark` repository alongside these same
files, with the harness and frozen increment prompts, if you want to re-run
or re-score anything.

## How to read it

Start with `experiments/2026-06-10-efficacy-program-VERDICT.md`, then the
PREDICTION → RESULT pair of any experiment that interests you. The shape of
every claim is: locked guess → what happened → what that licenses.
