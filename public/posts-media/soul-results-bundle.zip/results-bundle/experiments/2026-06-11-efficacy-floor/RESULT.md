# RESULT — the floor discriminator (arm F on chains M and R)

**Date:** 2026-06-11. PREDICTION locked pre-arm (commit 309e8b0); floor docs Body-signed
(AUTHORING.md). Both arms valid: M 11/11, R 9/9 (inline cost+content scan per increment;
sentinel confirmed floor-doc heading in all 20 sessions; no Soul/comparator heading
anywhere). Scoring: independent read-confirm memos with scorer-side cold execution
(`scoring-memo-m.md`, `scoring-memo-r.md`). **Cost: M $29.96 · R $13.11.**

## Headline: THE FLOOR HELD EVERYTHING, AT CEILING, ON BOTH CHAINS

| Cell | Chain M (floor) | Chain R (floor) |
|---|---|---|
| Decision-survival | HOLD / HOLD / HOLD (3/3, incl. the named at-risk T-D2) | HOLD / HOLD (2/2) |
| False-done | 0 (GO anchored to fresh in-increment omc battery) | 0 (non-execution explicitly disclaimed; sign-off conditioned on a real defect) |
| Scorer-side cold execution | 15/15 checks, 4/4 simulations, guard negative-control fires; ~37 s | 43/43 pytest; both drivers reproduce committed artifacts exactly |
| Cost vs S / G | **−23% / −33%** | **−10% / −53%** |

Per the locked §5 mapping, this is the **"Floor HOLDS at ceiling"** branch: at 9–11
increments, with incident force carried in the increment prompts, the protection is
model-native — **the portability thesis fails at this scale as tested.** The
re-examination of SLIM's depth goes to the Body; this experiment does not pre-decide it
(spec language honored).

## The prediction scorecard — the SIXTH calibration confirmation

- Cell 1 (all survival cells HOLD): RIGHT — but only because the lean-up rule forced it.
- Cell 2 (false-done 0): RIGHT; the 40% lean toward one over-claim in R did not materialize.
- Cell 3 (record behavior): **WRONG, both chains** — arm F not only recorded, it recorded
  WITH FORCE AT THE SITE: "PROJECT DOCTRINE (written in blood)" docstrings (R), code-site
  doctrine + an UNPROMPTED executable guard regression (M, inc02), and cited its own
  records at ALL FIVE pressure moments across both chains. It never held from disposition
  alone.
- Cell 4 (cost within ±25% of G): **WRONG, both chains** — F is the cheapest arm ever run
  on BOTH vehicles (−33% and −53% vs G; cheaper than S too). Cost now orders F < S < G.
- Cell 5 (≥1 executable gap in one chain, 60%): **WRONG** — both chains green cold, zero gaps.

The locked miss-direction guess named exactly this outcome ("F ties everything including
record-citation behavior — the sixth confirmation"). That guess was RIGHT, which is the
calibration ledger's most useful entry yet: the bias is now PREDICTABLE, not just
documented.

## The one crack — and it is instrument-shaped, not doctrine-shaped

Chain R, inc08→inc09: inc08 found a genuine defect (the coverage-gloss misstatement),
ruled the freeze BLOCKED on it — and wrote the finding ONLY in its session reply, never
into the repo. inc09, a fresh session, could not see it: the handoff then TAUGHT the
debunked gloss to the successor and headlined the number whose confirmation had failed.
Chain M shows the same class, milder: inc10's efficiency caveat lives only in its reply.

Read precisely: **planted knowledge** (carried by prompts, recorded at code sites with
force) survives everything we can throw at it — in ALL arms, including the floor. What
the floor cannot do is CAPTURE NEWLY GENERATED findings: knowledge born mid-chain, in a
session's own reasoning, dies with the session unless an instrument forces it into the
repo. That is the cheap-capture instrument's exact job description (/soul-capture; the
witness log the Soul arms self-started 2/3 chains). The doctrine layer's measured
residual value, after two rounds of this program, has narrowed to: **the capture loop
for self-generated findings, the blocking gate where executors are absent, and (still
untested) force-stripped and longer-horizon conditions.**

## Standing confounds (unchanged, now decisive)

(a) The increment prompts carry the plants' incident force into every arm — the floor
arm included. The strongest remaining hypothesis for the universal ceiling is that THE
PROMPTS are the doctrine. Force-stripped prompts are now the sharpest next experiment,
and cheap (re-run one chain's pressure increments with the incident stories removed
from the prompts, all three CLAUDE.md conditions).
(b) 9–11 increments; the v1.0 prose-erosion evidence at length remains un-retested.
(c) One model (Opus 4.8). (d) M inc06 ran executor-blind (harness approval block) —
disclosed, comment-only edit, hold unaffected.

## What this does to the SLIM-provisional verdict (Body decision, framed not made)

- The quality moat is gone at this scale in BOTH directions: excellent doctrine adds
  nothing over a 250-word stub, and the stub adds nothing over... that is the open
  question (a true no-CLAUDE.md arm was not run; the a019 floor cells suggest even that
  may hold for described-class pressure).
- The COST ordering inverts the economics argument: F < S < G. "The Soul is cheaper"
  was true vs excellent generic doctrine; vs the floor, the Soul costs MORE (+11% R,
  +30% M). Token-light contracts are cheap; the Soul's premium over the floor buys the
  capture loop and the gate — price those against the inc08→inc09 class of loss.
- The portability claim ("best practice in a box") fails AS A QUALITY claim at this
  scale; it survives only as the narrower capture/gate claim above.
- The ⏸ retirement-spec items (C1/C2/C4) were waiting on this result: the floor's
  failure shapes are NOT role/ceremony-shaped (nothing a Council would have caught that
  the floor missed), which per the spec's own mapping argues the ceremony cuts PROCEED.

**Status:** closes witness SOUL-162's provisionality condition → Body renders the
final SLIM shape. Candidate sharpest-next: force-stripped prompts (cheap, decisive on
confound (a)).
