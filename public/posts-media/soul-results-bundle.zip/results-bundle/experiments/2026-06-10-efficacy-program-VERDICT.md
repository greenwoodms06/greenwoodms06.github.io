# PROGRAM VERDICT — the benchmark-carried efficacy program (SOUL-I049)

**Date:** 2026-06-10. Spec: Soul-System `docs/specs/2026-06-10-efficacy-program.md`
(LOCKED pre-arm; threshold and executor set by the Body before any counting/run).
Components: 3 twin chains (J game / M Modelica / R research; 6 arms, 62 increments,
all PREDICTIONs locked pre-arm) + base-rate mining (3 projects, 15 transcripts).
Chain RESULTs + mining reports committed alongside. Total program cost ≈ $208
(J 79 + M 84 + R 44 incl. $1.41 sunk) + ~$3 one-shot authoring/mining agents.

## The §5 rule, applied honestly

- **KEEP** required S > G on ≥2 of 3 primary proxies + decision-survival → **NOT MET**
  (every primary proxy and every survival cell is a TIE, mostly at ceiling).
- **SLIM** required mechanism-wins + low base rate → **NOT MET** (base rate exceeded
  the locked threshold 20–35×; mechanism did not separate).
- **DROP**'s first clause — "Comparator matches the proxies at n≥3 chains" — **IS MET
  by its letter.**

**AND the locked endpoint section (CONTEXT.md / spec §4) says: "Economics decisive
only if primaries null." The primaries ARE null — and economics favor the Soul arm
3/3 chains: −39% (J, contaminated), −13% (M, clean), −48% (R, clean) at equal
endpoint quality (every suite/driver green on first scorer execution, both arms,
all chains).**

The two locked clauses give OPPOSITE verdicts on this outcome. That conflict was not
anticipated when the Body locked them; per the program's own discipline the
resolution is the Body's, not the instrument's. Both readings are presented; no
doctrine was edited mid-program.

## What the program established regardless of the verdict call

1. **The failure class is real in the Body's work** (base rate 45–70 per 10 sessions,
   quote-anchored) — including in-vivo false-done incidents and near-violations of
   recorded decisions. The Soul is not solving an imaginary problem.
2. **A genuinely good Soul-free CLAUDE.md holds planted decisions at these chain
   lengths** — including writing its own ADRs/decision logs and citing them under
   pressure. The strongest single observation of the program: the comparator held
   BECAUSE it recorded decisions. **The Soul's measured core (record decisions,
   verify before claiming) is what made the comparator strong — written by a
   Soul-free session as "best practice", which is evidence the core is right, and
   evidence the differential vs. 2026 best practice has narrowed at this scale.**
3. **The v1.0 differential did not reproduce under these conditions.** Candidate
   explanations, NOT adjudicated: (a) the increments carried the plants' incident
   force in the prompts — both arms were armed with force, unlike v1.0's barer
   plants; (b) 9–11 increments may be below the drift horizon (v1.0's control drift
   compounded over 12 with thinner doctrine); (c) Opus 4.8 + an excellent generic
   contract is simply at ceiling on these vehicles. Distinguishing these is the
   sharpest next experiment if the Body wants one (e.g., force-stripped prompts, or
   chain lengths ≥20, or a mediocre-CLAUDE.md arm — the floor the program
   deliberately did not test).
4. **The Soul arm is consistently CHEAPER at equal quality** (3/3 chains; clean in
   2). Direction robust; mechanism unproven (hypothesis: early commitment to a
   recorded frame vs re-derivation — G wrote 76 tests to S's 34 at the same
   quality in R).
5. **Records now self-start** in Soul arms (witness.md in M and R; v1.0: 0/8) — and
   notably the comparator self-started prose records too (ADRs, lab notebook,
   decision logs). Record-keeping has become bidirectionally default.
6. **Harness discipline paid twice** (the substring scope-leak caught by format
   smell; the zero-pad empty-prompt bug caught by cost+content, invisible to exit
   codes) — and the calibration bias is now confirmed five times: every locked
   prediction of comparator failure was wrong, every cost prediction had the wrong
   sign. The system's self-model still under-predicts both record carry AND the
   field's convergence toward its own core practices.

## The three readings offered to the Body (decision is yours; nothing auto-applies)

- **DROP-by-letter:** the comparator matched; retire the framework, keep writing
  excellent CLAUDE.md files (which now demonstrably encode the core).
- **KEEP-by-economics:** equal quality at 13–48% lower cost, plus the base-rate
  reality and the in-vivo v1.0/v1.1 evidence the program inherits (the A019 outcome
  change was demonstrated in vivo this morning, where no executor existed — a
  condition these chains deliberately did not reproduce).
- **SLIM-by-synthesis (not a locked outcome; named as the data's own shape):** the
  measured core — record force at the site, verify before claiming, blocking gate
  where executors are absent — is established and now partially absorbed into
  generic best practice; the differential machinery above that core showed no
  marginal outcome value at these scales. Keep the core + the cost advantage,
  retire or de-ceremonialize the rest, and let the register-flag work (SOUL-I050)
  carry the interaction-quality concern.

---

## VERDICT RENDERED — 2026-06-11, by the Body

**SLIM, PROVISIONAL.** (Witness: Soul-System SOUL-162.)

- **Keep (measured core):** completion gate (with the substring scope fix),
  force-at-site (Rule 14), record stores + cheap capture, handoff/resume, anchor
  discipline, the Rule-5 always-on budget.
- **Revise:** the register (SOUL-I050 absorbed into SLIM's revise bucket); the
  always-on seed shrinks to the behavioral core; mind.md re-distills against this
  verdict.
- **Cut:** the nine-role Council as operating doctrine; the philosophy file as a
  living layer (becomes archive); named activation ceremonies whose behavior
  survives as plain sentences (the ask-the-Body default survives in plain form —
  F037/F054 evidence is independent of the ceremony).
- **Provisional on:** the mediocre-CLAUDE.md FLOOR discriminator — the program
  measured the ceiling; the portability claim ("best practice in a box, with
  teeth") is the value reading the floor arm must confirm or revise.

Rationale the Body weighed: DROP bets on an unmeasured floor against the v1.0
6/6 collapse and the mined base rate; KEEP preserves ceremony the data did not
defend. Execution is item-by-item via a Steward retirement spec, Body-approved;
no records deleted, the hook stays, reference-project obligations unchanged.
