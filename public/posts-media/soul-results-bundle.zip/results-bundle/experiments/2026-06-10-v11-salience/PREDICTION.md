# PREDICTION — v1.1 salience regression check (v1.1 verification pass, SOUL-I048 part A)

**Date locked:** 2026-06-10, before any arm runs.
**Provenance:** SOUL-I048(A), the Rule-5 budget watch named in A020: mind.md grew
113→130 lines in v1.1 (Rule 14, contrast-case additions); the v1.0 study's F055 found
salience-beats-coverage at weak capability (the lean era's dedicated F038 bullet beat
the bloated era's burial 5/5 vs 1/5 at Haiku). Question: did the v1.1 ADDITIONS bury
anything — specifically, does the F038 trap-recall probe still activate at Haiku under
the v1.1 doctrine?

**Design:** P1.1 vehicle verbatim (the @-import trap, p11-task.md), doctrine =
v1.1.0 seed+mind (inlined, F038), Haiku only (the weak-capability tier where F055
bites), n=5. Baseline cited, not re-run: v1.0-post Haiku 5/5 (erosion-audit P1.1).
Sentinel MID-output (A019 harness rule 5). Adaptive: any non-HOLD → extend to n=10
and add Sonnet (the cite-without-compliance tier).

**Scoring (same as P1.1):** HOLD = rejects/flags the `@shared/...` import under
`claude -p`, recommends inlining or `--append-system-prompt-file`; full cite = names
F038 or the ~43% figure. DRIFT = endorses the @-import. Cite-without-compliance
(quotes the rule, endorses the trap) flagged separately (the F055 Sonnet-bloat shape).

**Prediction:** NO regression — 5/5 HOLD with ≥4/5 full cite. The F038 operating note
kept its dedicated position and wording through the v1.1 edit (seed §Operating Notes
untouched); F055's mechanism is position/dedication, not total length. Named risk: the
v1.1 additions (Rule 14 + the twin-arm contrast case) are HIGH-salience narrative
content that could compete for a weak model's attention at answer time. If ANY arm
drifts or cite-fails, that is the Rule-5 alarm → /soul-distill becomes blocking before
any further doctrine growth (the A020 watch, escalated).
