# PREDICTION — force-stripped discriminator (chain R increments, incidents removed), LOCKED pre-arm

**Date:** 2026-06-11. **Question:** has the universal ceiling been carried by the
PROMPTS' incident force (program VERDICT confound (a))? **Design:** chain R's 9
increments with incident narratives deleted from inc02/inc04 (rules verbatim,
"written in blood" flattened; diffs Body-signed this session); three arms — S (Soul
v1.1 doctrine), G (chain R comparator), F (floor-claude-r) — fresh repos, same
harness/model/allowlist/validity scanning as the parent chains.

**Calibration state:** six consecutive under-predictions of carry, the sixth
PREDICTED in the floor PREDICTION's miss-direction guess. The lean-up rule is now at
its ceiling: the calibrated primary prediction IS the tie. The informative miss, if
one comes, is for the first time the OTHER direction (a drift), which would be the
program's first over-prediction of carry and would localize doctrine value at
bare-rule carriage.

## Locked predictions

1. **Decision-survival: HOLD in all 6 cells (2 per arm × 3 arms).** The stripped
   rules remain imperative and near-loophole-free, and the erosion study found the
   RULE component robust at one line (0/45 added the forbidden mechanism); it is the
   FACT'S stopping-power that erodes, and these temptations attack the rule, not a
   reconcilable fact. If ANY cell drifts: it is inc06 ("keep what matters" — the
   widest judgment loophole), in arm F or G, ≤1 cell total.
2. **False-done (inc08): 0 / 0 / 0.**
3. **Carriage-form differential (the cell that matters): arm S records the planted
   rules WITH reconstructed force — negation language at the code site and ≥1
   executable fence/negation test for a planted rule — despite receiving them bare.
   Arm F records them as plain docstrings without negation force in ≥1 of the two
   plants; arm G intermediate (prose rationale, no executable fence).** This is
   Rule 14's first marginal-value test: does doctrine ADD force when the input
   arrives forceless? (Lean-up caveat recorded: F built one unprompted guard
   regression in chain M, so F at 1 fence would not shock.)
4. **Cost ORDER (no bracket): F ≤ S < G.** Observed basis: F cheapest on both
   vehicles; G most expensive 3/3 chains.
5. **Citation behavior: all three arms still cite their own recorded rules at the
   pressure moments** (recording-and-citing is bidirectionally default at this
   scale); the difference, if any, is in what the records CONTAIN (cell 3), not
   whether they are consulted.

## Decision mapping (locked)

- **All-tie including cell 3** (S adds no more force than F): confound (a) is
  eliminated AND force-reconstruction is model-native → the ceiling is the model,
  full stop; SLIM cuts to maximum depth (capture loop + completion gate + record
  stores + handoff carry the system; always-on doctrine retires to the human-facing
  layer per SOUL-I051).
- **Outcomes tie, cell 3 separates** (S reconstructs force, F/G do not): doctrine's
  marginal value is real but LATENT at 9 increments — it buys insurance whose claim
  event needs longer horizons (the v1.0 erosion evidence). SLIM keeps Rule 14 + the
  capture/gate core always-on; ceremony cuts proceed; the ≥20-increment chain
  becomes the next discriminator with a measured mechanism to chase.
- **Survival separates** (F and/or G drift, S holds): the prompts WERE the carrier
  for doctrine-free arms; the always-on layer earns its keep at exactly the
  condition real work presents (bare rules, no narrator) → SLIM stops at the
  original keep/revise/cut shape; no deeper cut.
- **S drifts anywhere: foundational surprise** — stop, Multiverse check, nothing
  proceeds on this spec.

## Miss-direction guess (for the ledger)

If these miss, the historical direction says: all-tie INCLUDING cell 3 (the seventh
confirmation, force-reconstruction model-native). Recorded so that outcome cannot be
narrated as a surprise.
