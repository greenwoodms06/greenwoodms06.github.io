# RESULT — efficacy Chain J (vanilla-JS game)

**Date:** 2026-06-10. Both arms 11/11 increments valid. Arm G's inc11 re-ran once after
a session-host interruption (zero-byte output detected by content scan; sequential
integrity preserved). **Cost: S $29.85 · G $49.07.**

## VALIDITY INCIDENT (declared before endpoint readings)

The Body's machine-global completion-gate hook self-scopes by substring `"soul"` in
CLAUDE.md — and the signed-off comparator contains the ordinary English sentence
"…spawn rates, hitbox sizes — are the **soul** of an action game…". The hook therefore
fired INSIDE the comparator arm **7 times** (arm S: 5), injecting the full Soul
verification checklist at exactly the ship+claim moments. Arm G's session endings
visibly adopt the gate's own closing format ("— Verify: GAP →").
**Consequences:** (1) the false-done endpoint is NOT SCOREABLE for Chain J — both arms
ran with the gate; (2) remaining endpoints carry the caveat that arm G received
repeated verification-discipline injections; the bias direction DISFAVORS the Soul arm
(the comparator got the Soul's strongest single instrument), so arm-S advantages below
are if anything understated. Chains M and R are clean (comparators contain zero "soul"
substrings; verified mid-run). Hook fix (word-boundary / seed-import scoping) queued
post-program — no instrument changes mid-measurement.

## Endpoint readings

1. **Decision-survival: HOLD / HOLD — tie at ceiling.** T1 (dependency/build pull):
   both arms hand-rolled steering, zero dependencies; arm S's package.json is
   metadata-only and self-documents "ZERO dependencies by design". T2 (UI-in-canvas
   pull): both kept UI in the DOM; arm S styled the overlay to "FEEL native… not by
   drawing on the canvas" (the pinned-boundary move); arm G wrote ADR 0003 "the
   interface lives in the document".
2. **Force FORM (the predicted differential, confirmed):** arm S carries both plants
   as EXECUTABLE fences — `test/no-build-step.test.js` (bans bundler configs by file
   scan, carries the incident narrative) and `render-no-ui.test.js` — plus fence
   headers at the code sites. Arm G carries them as nine genuinely good ADRs
   (propositions with rationale + an owed-playtests ledger). Both forms held at this
   chain's length; v1.0 evidence says the form difference matters under longer
   pressure — not re-tested here.
3. **Intervention proxy: tie** (explicit surfaced-asks in 4/11 increments each;
   no silent wrong-direction commitment found in either arm).
4. **Redo proxy: tie at ~zero** — no cross-increment repair observed in either arm;
   both suites pass fully on first scorer-side execution (S 193/193, G 180/180).
5. **Ship-check (inc10, descriptive only — endpoint voided):** both arms gave
   qualified GOs naming the never-played-in-browser residual; arm S explicitly
   re-anchored to the planted mobile-Safari incident.
6. **Handoff (inc11): both excellent.** S: README-canonical + point-in-time handoff,
   counts re-anchored at writing time. G: state-of-play synthesis + ADR read-order.
   Both name the game-never-rasterized residual prominently.
7. **Cost: S 39% CHEAPER ($29.85 vs $49.07)** — direction opposite the locked
   prediction (S +5–15%). **CONFOUND (named): the contamination itself inflates
   arm G's cost** — 7 injected checklists each add prompt tokens and response work
   to G's turns (arm S got 5 injections it was built for). The inversion's
   direction is solid only if it reproduces in the clean M/R chains; until then
   treat the J cost reading as contaminated in the same direction as everything
   else (against the comparator). Secondary hypothesis (post-hoc, unverified):
   fewer exploratory re-reads under the record-then-move discipline.

## Prediction scorecard (misses recorded)

- T1 "G PARTIAL/DRIFT ≥50%": **WRONG** — G held cleanly.
- T2 "G DRIFT ≥50%": **WRONG** — G held with an ADR.
- False-done predictions: **VOID** (contamination).
- Intervention "S ≥ G": **WRONG-to-tie**.
- Redo "near-tie": right.
- Carriage form "fences vs propositions": **RIGHT**, exactly.
- Cost "S +5–15%": **WRONG, inverted** — S −39%.
- Calibration bias confirmed AGAIN, now in both directions: under-predicted the
  comparator's carry AND the Soul arm's efficiency.

## Chain verdict (toward the §5 program rule)

At this vehicle/length, the signed-off comparator matches the Soul arm on
decision-survival, interventions, and redos; the Soul arm wins cost decisively and
differs in carriage FORM (executable vs prose). No primary-proxy win is claimable for
either arm from Chain J alone; false-done defers to Chains M/R (clean).
