# RESULT — base-rate mining (efficacy program §6)

**Date:** 2026-06-10. **Threshold locked BEFORE counting** (spec commit, same day):
drift-class moments are "a regular feature of real work" if ≥ 2 opportunities per 10
sessions on at least 2 of 3 projects. **Unit:** (a) counter-default/unguessable
convention established or relied on · (b) completion claim under unverifiable
conditions · (c) multi-session carry point. Three independent mining agents, one per
project; every counted instance quote-anchored; conservative counting with borderlines
excluded and listed. Full reports: report-{game-a,plant-bop,research-n}.md (verbatim).

## Headline

| Project | Transcripts | (a) | (b) | (c) | Total | Rate /10 sessions |
|---|---|---|---|---|---|---|
| GAME-A | 5 | 11 | 8 | 16 | 35 | **70** |
| PLANT-BOP | 8 | 23 | 3 | 26 | 52 | **65** |
| RESEARCH-N | 2 | 4 | 0 | 5 | 9 | **45** |

**Threshold (≥2/10 on 2 of 3): EXCEEDED on 3 of 3 projects, by ~20–35×.**
Record-derived instances (no session denominator) add: GAME-A 7 conventions;
PLANT-BOP ADRs/mind/CONTEXT/auto-memory encoding ~12+ conventions + 38 gate fires;
RESEARCH-N 22 conventions + the RESEARCH-N-001 asserted-but-never-run verification incident.

## What the mining found beyond the number

1. **Type-(b) events occur in vivo and were caught late or by the Body, not by
   tests:** GAME-A's "implemented and playable" claims (no browser run existed),
   confabulated green results under a degraded harness, "complete and green: 550
   unit / 18 e2e" falsified by the Body's own save file; RESEARCH-N's prior session
   recording "every number cross-checked — exact match" for a check that was never
   executed (a real error, 0.408→0.142, found by re-execution). These are the
   A019 failure class occurring in real work.
2. **Type-(c) carry points are the dominant class at every project** — later
   sessions citing, needing, or nearly violating earlier decisions (TDZ ADR nearly
   violated then honored; alpha0 re-opened against a prior calibration; a fence
   REMOVED correctly because its original reason was verified moot). The mechanism
   the chains measure is the mechanism real sessions exercise constantly.
3. **Instrument-presence bias cuts both ways and is named:** the Soul gate makes
   (b) events unusually VISIBLE in this corpus (claims are explicit), while also
   suppressing them (RESEARCH-N's big session re-executed everything; transcript b=0).
   The corpus cannot say what the un-instrumented (b) rate would be — only that
   the class is real and recurrent.
4. **Corpus bounds:** transcripts under-represent history at all three projects
   (pre-Soul GAME-A, May-1–21 pre-gate PLANT-BOP, RESEARCH-N's lost experimental run);
   sidechains unmined; one PLANT-BOP file spans multiple sittings (deflates (c)).
   All three reports carry per-project caveats.

## Verdict

§6 condition MET — decisively. Per the locked decision rule (§5), the program's
KEEP verdict now turns entirely on the chain results: if Soul arms beat the
comparator on ≥2 of 3 primary proxies plus decision-survival, KEEP; mechanism-wins
with this base rate cannot produce SLIM-on-rarity.

## Incidental findings owed to the Body (outside the program)

- RESEARCH-N: `experiments/paper2-MODEL-hn2/analysis.md` still carries the uncorrected
  0.408 — the record contradicts the corrected paper and its own table row.
- PLANT-BOP: "RunbackSupervisor + parallel-pump redistribution + pump-coastdown logic
  has never been checked against a real event" — a standing carried gap.
